﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using ProjectManager.Model;

namespace ProjectManager
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        /*
        private static LoadData loadData = new LoadData();

        public static LoadData LoadData
        {
            get { return loadData; }
        }
        */
    }
}
